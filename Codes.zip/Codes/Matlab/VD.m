clc
clear
close all


verbose='on';

 data_set = 'cuprite';
% data_set = 'jasper';
% data_set = 'sameson';
% data_set = 'urban';
t=0.00001;
if strcmp(verbose,'on'),fprintf(1,'loading %s data set\n',data_set);end

switch data_set
    case 'urban'
         datas = load('Urban_R162.mat');
         B=datas.nBand;
         x=datas.Y;
         wavlen=1:B;
         SlectBands=datas.SlectBands';
         BANDS=SlectBands;
         [B N]=size(x);
         noise_type='poisson';
         
         [w Rn] = estNoise(x,noise_type,verbose);
         [kf Ek]=hysime(x,w,Rn,verbose);
         nHySime=kf;
         disp(' ')
         disp('HFC with Error "10^-8"')
         nHFC = HFC(datas.Y,t);

         disp('NWHFC with Error "10^-8"')
         nNWHFC = NWHFC(datas.Y,t);
         
    case 'jasper'
         datas = load('jasperRidge2_R198.mat');
         B=datas.nBand;
         x=datas.Y;
         wavlen=1:B;
         SlectBands=datas.SlectBands';
         BANDS=SlectBands;
         [B N]=size(x);
         noise_type='poisson';
         
         [w Rn] = estNoise(x,noise_type,verbose);
         [kf Ek]=hysime(x,w,Rn,verbose);
         nHySime=kf;
         disp(' ')
         
         disp('HFC with Error "10^-8"')
         nHFC = HFC(datas.Y,t);

         disp('NWHFC with Error "10^-8"')
         nNWHFC = NWHFC(datas.Y,t);
         
    case 'sameson'
         datas= load ('samson_1.mat'); 
         B=datas.nBand;
         x=datas.V;
         wavlen=1:B;
         BANDS=B;
         [B N]=size(x);
         noise_type='additive';
         
         [w Rn] = estNoise(x,noise_type,verbose);
         [kf Ek]=hysime(x,w,Rn,verbose);
         nHySime=kf;
         disp(' ')
         
         disp('HFC with Error "10^-8"')
         nHFC = HFC(datas.V,t);

         disp('NWHFC with Error "10^-8"')
         nNWHFC = NWHFC(datas.V,t);
         
    case 'cuprite'
         datas = load('CupriteS1_R188.mat');
         B=datas.nBand;
         x=datas.Y;
         wavlen=1:B;
         SlectBands=datas.SlectBands';
         BANDS=SlectBands;
         [B N]=size(x);
         noise_type='poisson';
         
         [w Rn] = estNoise(x,noise_type,verbose);
         [kf Ek]=hysime(x,w,Rn,verbose);
         nHySime=kf;
         disp(' ')
         disp('HFC with Error "10^-8"')
         nHFC = HFC(datas.Y,t);

         disp('NWHFC with Error "10^-8"')
         nNWHFC = NWHFC(datas.Y,t);
         
end


